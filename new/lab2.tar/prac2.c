/**
 * \file
 *         A TCP socket echo server. Listens and replies on port 8080
 * \author
 *         mds
 */

#include "contiki-net.h"
#include "sys/cc.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "contiki.h"
#include "dev/leds.h"
#include "dev/serial-line.h"
#include "dev/cc26xx-uart.h"
#include "buzzer.h"
#include "sys/ctimer.h"

#include "board-peripherals.h"

/*---------------------------------------------------------------------------
define the global symbols for easily change
---------------------------------------------------------------------------*/
#define BUTTON_ON 1
#define BUTTON_OFF 0
#define BUZZ_FREQUENCY 1500
#define BUZZ_COUNTER 0
#define HDC_COUNTER 0
#define BMP_COUNTER 0
#define SAMPLE_TIME 2

/*---------------------------------------------------------------------------
global variables for function access
---------------------------------------------------------------------------*/
char led_red_state = BUTTON_OFF; // init off
char led_green_state = BUTTON_OFF; // init off
char led_all_state = BUTTON_OFF; // init off
char buz_state = BUTTON_OFF; // init off
int hdc_state = BUTTON_OFF; // init off
int bmp_state = BUTTON_OFF; // init off
int buz_freq = BUZZ_FREQUENCY;	// init 1000
char buzz_counter = BUZZ_COUNTER; // init 0
char hdc_counter = HDC_COUNTER; // init 0
int bmp_counter = BMP_COUNTER; // init 0
char hdc_sample_time = SAMPLE_TIME; // 2s per time
int bmp_sample_time = SAMPLE_TIME; // 2s per time
static struct ctimer timer_buzz_ctimer; //Callback Timer
static struct ctimer timer_red_ctimer; //Callback Timer
static struct ctimer timer_green_ctimer; //Callback Timer
static struct ctimer timer_all_ctimer; //Callback Timer	
static struct ctimer timer_hdc_ctimer; //Callback Timer	
static struct ctimer timer_bmp_ctimer;

#define SERVER_PORT 8080

static struct tcp_socket socket;

#define INPUTBUFSIZE 400
static uint8_t inputbuf[INPUTBUFSIZE];

#define OUTPUTBUFSIZE 400
static uint8_t outputbuf[OUTPUTBUFSIZE];

PROCESS(tcp_server_process, "TCP echo process");
AUTOSTART_PROCESSES(&tcp_server_process);
static uint8_t get_received;
static int bytes_to_send;

/*---------------------------------------------------------------------------
functions to realize the different demand of requirements
use call back to make the program running async without many processes
and multi-thread, the three different functions can run at the same time.
---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
1 functions to realize led red on and off with freq of 1Hz
---------------------------------------------------------------------------*/
void show_toggle_led_red() {
	ctimer_reset(&timer_red_ctimer);
	leds_toggle(LEDS_RED);		//Toggle RED LED
}

/*---------------------------------------------------------------------------
2 functions to realize led green on and off with freq of 1Hz
---------------------------------------------------------------------------*/
void show_toggle_led_green() {
	ctimer_reset(&timer_green_ctimer);
	leds_toggle(LEDS_GREEN);		//Toggle GREEN LED
}

/*---------------------------------------------------------------------------
3 functions to realize led all on and off with freq of 1Hz
---------------------------------------------------------------------------*/
void show_toggle_led_all() {
	ctimer_reset(&timer_all_ctimer);
	leds_toggle(LEDS_ALL);		//Toggle ALL LED
}

/*---------------------------------------------------------------------------
4 functions to realize the buzz on and off, keep on and off when press b
---------------------------------------------------------------------------*/
void show_buzz_on_off() {
	if (buz_state == BUTTON_ON) {
		buzzer_stop();
		buz_state = BUTTON_OFF;
	} else {
		buzzer_start(buz_freq);
		buz_state = BUTTON_ON;
	}
}

/*---------------------------------------------------------------------------
5 functions to realize the buzz freq increase 50Hz per second, press 'i': increase 
100 Hz per seconds, after 5 seconds keep the beep until press b again
---------------------------------------------------------------------------*/
static void buzz_callback_inc_freq() {
	if (buz_state == BUTTON_ON && buzz_counter < 5) {
		buz_freq += 100;
		buzzer_start(buz_freq);
		ctimer_reset(&timer_buzz_ctimer);
		buzz_counter++;
	}
	if (buz_state == BUTTON_ON && buzz_counter == 5) {
		buz_freq = BUZZ_FREQUENCY;
	}
}
/*---------------------------------------------------------------------------
6 functions to realize the buzz freq increase 50Hz per second, press 'd': decrease 
100 Hz per seconds, after 5 seconds keep the beep until press d again
---------------------------------------------------------------------------*/
static void buzz_callback_dec_freq() {
	if (buz_state == BUTTON_ON && buzz_counter < 5) {
		buz_freq -= 100;
		buzzer_start(buz_freq);
		ctimer_reset(&timer_buzz_ctimer);
		buzz_counter++;
	}
	if (buz_state == BUTTON_ON && buzz_counter == 5) {
		buz_freq = BUZZ_FREQUENCY;
	}
}

/*---------------------------------------------------------------------------
7 functions to realize when pressing 'h', remotely collect 10 samples from
humidity sensor, and reading time is 0.5s
---------------------------------------------------------------------------*/
void get_humidity_sample() {
	if (hdc_counter < 10 && hdc_state == BUTTON_ON) {
		int temp_of_humidity;
		int val_of_humidity;
		temp_of_humidity = hdc_1000_sensor.value(HDC_1000_SENSOR_TYPE_TEMP);
		val_of_humidity = hdc_1000_sensor.value(HDC_1000_SENSOR_TYPE_HUMIDITY);
		char array_of_humidity[200];
		sprintf(array_of_humidity, "Sample=%d, Humidity=%d.%02d %%RH, Temp=%d.%02d C\n\r", hdc_counter+1, val_of_humidity/100, val_of_humidity%100, temp_of_humidity/100, temp_of_humidity%100);
		tcp_socket_send_str(&socket, array_of_humidity);
		hdc_counter++;
		SENSORS_ACTIVATE(hdc_1000_sensor);
		ctimer_reset(&timer_hdc_ctimer);
	} 

	if (hdc_counter == 10 && hdc_state == BUTTON_ON) {
		hdc_state = BUTTON_OFF;
		ctimer_stop(&timer_hdc_ctimer);
	}
}

void collect_humidity_sample() {
	if (hdc_state == BUTTON_OFF) {
		hdc_state = BUTTON_ON;
		hdc_counter = HDC_COUNTER;
		SENSORS_ACTIVATE(hdc_1000_sensor);
		ctimer_set(&timer_hdc_ctimer, CLOCK_SECOND * hdc_sample_time, get_humidity_sample, NULL);
	} else {
		ctimer_stop(&timer_hdc_ctimer);
		hdc_state = BUTTON_OFF;
	}
}

/*---------------------------------------------------------------------------
8 functions to realize when pressing 'p', remotely collect 10 samples from
humidity sensor, and reading time is 0.5s
---------------------------------------------------------------------------*/
void get_pressure_sample() {
	if (bmp_counter < 10 && bmp_state == BUTTON_ON) {
		int temp_of_pressure;
		int val_of_pressure;
		temp_of_pressure = bmp_280_sensor.value(BMP_280_SENSOR_TYPE_TEMP);
		val_of_pressure = bmp_280_sensor.value(BMP_280_SENSOR_TYPE_PRESS);
		char array_of_pressure[200];
		sprintf(array_of_pressure, "Sample=%d, Pressure=%d.%02d hPa, Temp:%d.%02d C\n\r", bmp_counter+1, val_of_pressure/100, val_of_pressure%100, temp_of_pressure/100, temp_of_pressure%100);
		tcp_socket_send_str(&socket, array_of_pressure);
		bmp_counter++;
		SENSORS_ACTIVATE(bmp_280_sensor);
		ctimer_reset(&timer_bmp_ctimer);
	}

	if (bmp_counter == 10 && bmp_state == BUTTON_ON){
		ctimer_stop(&timer_bmp_ctimer);
		bmp_state = BUTTON_OFF;
	}
}

void collect_pressure_sample() {
	if (hdc_state == BUTTON_OFF) {
		bmp_state = BUTTON_ON;
		bmp_counter = BMP_COUNTER;
		SENSORS_ACTIVATE(bmp_280_sensor);
		ctimer_set(&timer_bmp_ctimer, CLOCK_SECOND * bmp_sample_time, get_pressure_sample, NULL);
	} else {
		ctimer_stop(&timer_bmp_ctimer);
		bmp_state = BUTTON_OFF;
	}
}
/*---------------------------------------------------------------------------*/
//Input data handler
static int input(struct tcp_socket *s, void *ptr, const uint8_t *inputptr, int inputdatalen) {

	printf("input %d bytes '%s'\n\r", inputdatalen, inputptr);
	char data = inputptr[0];
	if (data == 'a') { // start conditional input
		if (led_all_state == BUTTON_OFF) {
			led_all_state = BUTTON_ON;
			ctimer_set(&timer_all_ctimer, CLOCK_SECOND, show_toggle_led_all, NULL);
		} else {
			led_all_state = BUTTON_OFF;
			ctimer_stop(&timer_all_ctimer);
		}
			
	} else if (data == 'g') {
		if (led_green_state == BUTTON_OFF) {
			led_green_state = BUTTON_ON;
			ctimer_set(&timer_green_ctimer, CLOCK_SECOND, show_toggle_led_green, NULL);
		} else {
			led_green_state = BUTTON_OFF;
			ctimer_stop(&timer_green_ctimer);
		}
			
	} else if (data == 'r') {
		if (led_red_state == BUTTON_OFF) {
			led_red_state = BUTTON_ON;
			ctimer_set(&timer_red_ctimer, CLOCK_SECOND, show_toggle_led_red, NULL);
		} else {
			led_red_state = BUTTON_OFF;
			ctimer_stop(&timer_red_ctimer);
		}
	} else if (data == 'b') {
		show_buzz_on_off();
	} else if (data == 'i') {
		buzz_counter = 0;
		ctimer_set(&timer_buzz_ctimer, CLOCK_SECOND, buzz_callback_inc_freq, NULL);
	} else if (data == 'd') {
		buzz_counter = 0;
		ctimer_set(&timer_buzz_ctimer, CLOCK_SECOND, buzz_callback_dec_freq, NULL);
	} else if (data == 'h') {
		collect_humidity_sample();
	} 
	else if (data == 'p') {
		collect_pressure_sample();
	} 

	tcp_socket_send_str(&socket, inputptr);	//Reflect byte


	//Clear buffer
	memset(inputptr, 0, inputdatalen);
    return 0; // all data consumed 
}

/*---------------------------------------------------------------------------*/
//Event handler
static void event(struct tcp_socket *s, void *ptr, tcp_socket_event_t ev) {
  printf("event %d\n", ev);
}

/*---------------------------------------------------------------------------*/
//TCP Server process
PROCESS_THREAD(tcp_server_process, ev, data) {

  	PROCESS_BEGIN();

	//Register TCP socket
  	tcp_socket_register(&socket, NULL,
               inputbuf, sizeof(inputbuf),
               outputbuf, sizeof(outputbuf),
               input, event);
  	tcp_socket_listen(&socket, SERVER_PORT);

	printf("Listening on %d\n", SERVER_PORT);
	
	while(1) {
	
		//Wait for event to occur
		PROCESS_PAUSE();
	}
	PROCESS_END();
}
/*---------------------------------------------------------------------------*/
