lab1
===========

This adds the lab1 process in hello-world.c to the platform build, which
prints "mac address" by pressing 'm' to stdout on startup and toggles the SensorTag's Red LED, GREEN LED, ALL LED, every second by pressing 'r', 'g', 'a'. Increase and decrease beep by pressing 'i' and 'd'.

